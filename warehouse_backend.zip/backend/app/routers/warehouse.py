from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user, require_admin

router = APIRouter(
    prefix="/api/warehouses",
    tags=["Warehouses"]
)


class WarehouseCreate(BaseModel):
    warehouse_code: str = Field(min_length=1, max_length=20)
    warehouse_name: str = Field(min_length=1, max_length=100)
    location: Optional[str] = Field(default=None, max_length=255)
    capacity: Optional[int] = Field(default=None, ge=0)
    status: str = "Active"


class WarehouseUpdate(BaseModel):
    warehouse_code: Optional[str] = Field(default=None, min_length=1, max_length=20)
    warehouse_name: Optional[str] = Field(default=None, min_length=1, max_length=100)
    location: Optional[str] = Field(default=None, max_length=255)
    capacity: Optional[int] = Field(default=None, ge=0)
    status: Optional[str] = None


VALID_STATUSES = ["Active", "Inactive"]


# GET ALL WAREHOUSES
@router.get("/")
def get_warehouses(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    result = db.execute(text("""
        SELECT
            warehouse_id,
            warehouse_code,
            warehouse_name,
            location,
            capacity,
            status,
            created_at
        FROM warehouses
        ORDER BY warehouse_id ASC
    """))

    warehouses = [dict(row) for row in result.mappings().all()]

    return {
        "count": len(warehouses),
        "warehouses": warehouses
    }


# GET ONE WAREHOUSE
@router.get("/{warehouse_id}")
def get_warehouse(
    warehouse_id: int,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    result = db.execute(text("""
        SELECT
            warehouse_id,
            warehouse_code,
            warehouse_name,
            location,
            capacity,
            status,
            created_at
        FROM warehouses
        WHERE warehouse_id = :warehouse_id
    """), {
        "warehouse_id": warehouse_id
    })

    warehouse = result.mappings().first()

    if not warehouse:
        raise HTTPException(
            status_code=404,
            detail="Warehouse not found"
        )

    return {
        "warehouse": dict(warehouse)
    }


# CREATE WAREHOUSE - ADMIN ONLY
@router.post("/")
def create_warehouse(
    warehouse: WarehouseCreate,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    if warehouse.status not in VALID_STATUSES:
        raise HTTPException(
            status_code=400,
            detail="Status must be Active or Inactive"
        )

    existing = db.execute(text("""
        SELECT warehouse_id
        FROM warehouses
        WHERE warehouse_code = :warehouse_code
    """), {
        "warehouse_code": warehouse.warehouse_code
    }).mappings().first()

    if existing:
        raise HTTPException(
            status_code=409,
            detail="Warehouse code already exists"
        )

    try:
        result = db.execute(text("""
            INSERT INTO warehouses (
                warehouse_code,
                warehouse_name,
                location,
                capacity,
                status
            )
            VALUES (
                :warehouse_code,
                :warehouse_name,
                :location,
                :capacity,
                :status
            )
        """), warehouse.model_dump())

        db.commit()

        return {
            "message": "Warehouse created successfully",
            "warehouse_id": result.lastrowid
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to create warehouse"
        )


# UPDATE WAREHOUSE - ADMIN ONLY
@router.put("/{warehouse_id}")
def update_warehouse(
    warehouse_id: int,
    warehouse: WarehouseUpdate,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    existing = db.execute(text("""
        SELECT warehouse_id
        FROM warehouses
        WHERE warehouse_id = :warehouse_id
    """), {
        "warehouse_id": warehouse_id
    }).mappings().first()

    if not existing:
        raise HTTPException(
            status_code=404,
            detail="Warehouse not found"
        )

    data = warehouse.model_dump(exclude_unset=True)

    if not data:
        raise HTTPException(
            status_code=400,
            detail="No fields provided for update"
        )

    if "status" in data and data["status"] not in VALID_STATUSES:
        raise HTTPException(
            status_code=400,
            detail="Status must be Active or Inactive"
        )

    if "warehouse_code" in data:
        duplicate = db.execute(text("""
            SELECT warehouse_id
            FROM warehouses
            WHERE warehouse_code = :warehouse_code
              AND warehouse_id <> :warehouse_id
        """), {
            "warehouse_code": data["warehouse_code"],
            "warehouse_id": warehouse_id
        }).mappings().first()

        if duplicate:
            raise HTTPException(
                status_code=409,
                detail="Warehouse code already exists"
            )

    allowed_fields = {
        "warehouse_code",
        "warehouse_name",
        "location",
        "capacity",
        "status"
    }

    fields = [
        field for field in data.keys()
        if field in allowed_fields
    ]

    set_clause = ", ".join(
        f"{field} = :{field}"
        for field in fields
    )

    data["warehouse_id"] = warehouse_id

    try:
        db.execute(text(f"""
            UPDATE warehouses
            SET {set_clause}
            WHERE warehouse_id = :warehouse_id
        """), data)

        db.commit()

        return {
            "message": "Warehouse updated successfully",
            "warehouse_id": warehouse_id
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to update warehouse"
        )


# DELETE WAREHOUSE - ADMIN ONLY
@router.delete("/{warehouse_id}")
def delete_warehouse(
    warehouse_id: int,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    existing = db.execute(text("""
        SELECT warehouse_id
        FROM warehouses
        WHERE warehouse_id = :warehouse_id
    """), {
        "warehouse_id": warehouse_id
    }).mappings().first()

    if not existing:
        raise HTTPException(
            status_code=404,
            detail="Warehouse not found"
        )

    try:
        db.execute(text("""
            DELETE FROM warehouses
            WHERE warehouse_id = :warehouse_id
        """), {
            "warehouse_id": warehouse_id
        })

        db.commit()

        return {
            "message": "Warehouse deleted successfully",
            "warehouse_id": warehouse_id
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to delete warehouse"
        )