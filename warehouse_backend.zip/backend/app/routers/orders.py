from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user, require_admin


router = APIRouter(
    prefix="/api/orders",
    tags=["Orders"]
)


VALID_STATUSES = [
    "Pending",
    "Processing",
    "Completed",
    "Cancelled"
]


class OrderCreate(BaseModel):
    order_code: str = Field(
        min_length=1,
        max_length=20
    )
    product_id: int
    quantity: int = Field(gt=0)
    customer_name: str = Field(
        min_length=1,
        max_length=100
    )
    staff_id: Optional[int] = None
    status: str = "Pending"
    order_date: Optional[date] = None


class OrderUpdate(BaseModel):
    order_code: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=20
    )
    product_id: Optional[int] = None
    quantity: Optional[int] = Field(
        default=None,
        gt=0
    )
    customer_name: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=100
    )
    staff_id: Optional[int] = None
    status: Optional[str] = None
    order_date: Optional[date] = None


@router.get("/")
def get_orders(
    search: Optional[str] = Query(
        default=None,
        max_length=100
    ),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if search:
        query = text("""
            SELECT
                o.order_id,
                o.order_code,
                o.product_id,
                p.product_code,
                p.product_name,
                o.quantity,
                o.customer_name,
                o.staff_id,
                s.staff_code,
                s.name AS staff_name,
                o.status,
                o.order_date,
                o.created_at
            FROM orders o
            LEFT JOIN products p
                ON o.product_id = p.product_id
            LEFT JOIN staff s
                ON o.staff_id = s.staff_id
            WHERE o.order_code LIKE :search
               OR o.customer_name LIKE :search
               OR o.status LIKE :search
               OR p.product_name LIKE :search
            ORDER BY o.order_id DESC
        """)

        result = db.execute(
            query,
            {"search": f"%{search}%"}
        )

    else:
        query = text("""
            SELECT
                o.order_id,
                o.order_code,
                o.product_id,
                p.product_code,
                p.product_name,
                o.quantity,
                o.customer_name,
                o.staff_id,
                s.staff_code,
                s.name AS staff_name,
                o.status,
                o.order_date,
                o.created_at
            FROM orders o
            LEFT JOIN products p
                ON o.product_id = p.product_id
            LEFT JOIN staff s
                ON o.staff_id = s.staff_id
            ORDER BY o.order_id DESC
        """)

        result = db.execute(query)

    orders = [
        dict(row)
        for row in result.mappings().all()
    ]

    return {
        "count": len(orders),
        "orders": orders
    }


@router.get("/{order_id}")
def get_order(
    order_id: int,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = text("""
        SELECT
            o.order_id,
            o.order_code,
            o.product_id,
            p.product_code,
            p.product_name,
            o.quantity,
            o.customer_name,
            o.staff_id,
            s.staff_code,
            s.name AS staff_name,
            o.status,
            o.order_date,
            o.created_at
        FROM orders o
        LEFT JOIN products p
            ON o.product_id = p.product_id
        LEFT JOIN staff s
            ON o.staff_id = s.staff_id
        WHERE o.order_id = :order_id
    """)

    result = db.execute(
        query,
        {"order_id": order_id}
    )

    order = result.mappings().first()

    if not order:
        raise HTTPException(
            status_code=404,
            detail="Order not found"
        )

    return {
        "order": dict(order)
    }


@router.post("/")
def create_order(
    order: OrderCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if order.status not in VALID_STATUSES:
        raise HTTPException(
            status_code=400,
            detail="Invalid order status"
        )

    # Check order code
    existing_order = db.execute(
        text("""
            SELECT order_id
            FROM orders
            WHERE order_code = :order_code
        """),
        {"order_code": order.order_code}
    ).mappings().first()

    if existing_order:
        raise HTTPException(
            status_code=409,
            detail="Order code already exists"
        )

    # Check product
    product = db.execute(
        text("""
            SELECT product_id
            FROM products
            WHERE product_id = :product_id
        """),
        {"product_id": order.product_id}
    ).mappings().first()

    if not product:
        raise HTTPException(
            status_code=404,
            detail="Product not found"
        )

    # Check staff if supplied
    if order.staff_id is not None:

        staff = db.execute(
            text("""
                SELECT staff_id
                FROM staff
                WHERE staff_id = :staff_id
                  AND status = 'Active'
            """),
            {"staff_id": order.staff_id}
        ).mappings().first()

        if not staff:
            raise HTTPException(
                status_code=404,
                detail="Active staff member not found"
            )

    order_date = order.order_date or date.today()

    try:
        result = db.execute(
            text("""
                INSERT INTO orders (
                    order_code,
                    product_id,
                    quantity,
                    customer_name,
                    staff_id,
                    status,
                    order_date
                )
                VALUES (
                    :order_code,
                    :product_id,
                    :quantity,
                    :customer_name,
                    :staff_id,
                    :status,
                    :order_date
                )
            """),
            {
                "order_code": order.order_code,
                "product_id": order.product_id,
                "quantity": order.quantity,
                "customer_name": order.customer_name,
                "staff_id": order.staff_id,
                "status": order.status,
                "order_date": order_date
            }
        )

        db.commit()

        return {
            "message": "Order created successfully",
            "order_id": result.lastrowid
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to create order"
        )


@router.put("/{order_id}")
def update_order(
    order_id: int,
    order: OrderUpdate,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    existing = db.execute(
        text("""
            SELECT order_id
            FROM orders
            WHERE order_id = :order_id
        """),
        {"order_id": order_id}
    ).mappings().first()

    if not existing:
        raise HTTPException(
            status_code=404,
            detail="Order not found"
        )

    data = order.model_dump(exclude_unset=True)

    if not data:
        raise HTTPException(
            status_code=400,
            detail="No fields provided for update"
        )

    if "status" in data:
        if data["status"] not in VALID_STATUSES:
            raise HTTPException(
                status_code=400,
                detail="Invalid order status"
            )

    if "product_id" in data:
        product = db.execute(
            text("""
                SELECT product_id
                FROM products
                WHERE product_id = :product_id
            """),
            {"product_id": data["product_id"]}
        ).mappings().first()

        if not product:
            raise HTTPException(
                status_code=404,
                detail="Product not found"
            )

    if "staff_id" in data and data["staff_id"] is not None:
        staff = db.execute(
            text("""
                SELECT staff_id
                FROM staff
                WHERE staff_id = :staff_id
                  AND status = 'Active'
            """),
            {"staff_id": data["staff_id"]}
        ).mappings().first()

        if not staff:
            raise HTTPException(
                status_code=404,
                detail="Active staff member not found"
            )

    if "order_code" in data:

        duplicate = db.execute(
            text("""
                SELECT order_id
                FROM orders
                WHERE order_code = :order_code
                  AND order_id <> :order_id
            """),
            {
                "order_code": data["order_code"],
                "order_id": order_id
            }
        ).mappings().first()

        if duplicate:
            raise HTTPException(
                status_code=409,
                detail="Order code already exists"
            )

    allowed_fields = {
        "order_code",
        "product_id",
        "quantity",
        "customer_name",
        "staff_id",
        "status",
        "order_date"
    }

    fields = [
        field
        for field in data.keys()
        if field in allowed_fields
    ]

    set_clause = ", ".join(
        f"{field} = :{field}"
        for field in fields
    )

    data["order_id"] = order_id

    try:
        db.execute(
            text(f"""
                UPDATE orders
                SET {set_clause}
                WHERE order_id = :order_id
            """),
            data
        )

        db.commit()

        return {
            "message": "Order updated successfully",
            "order_id": order_id
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to update order"
        )


@router.delete("/{order_id}")
def delete_order(
    order_id: int,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    existing = db.execute(
        text("""
            SELECT order_id
            FROM orders
            WHERE order_id = :order_id
        """),
        {"order_id": order_id}
    ).mappings().first()

    if not existing:
        raise HTTPException(
            status_code=404,
            detail="Order not found"
        )

    try:
        db.execute(
            text("""
                DELETE FROM orders
                WHERE order_id = :order_id
            """),
            {"order_id": order_id}
        )

        db.commit()

        return {
            "message": "Order deleted successfully",
            "order_id": order_id
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to delete order"
        )