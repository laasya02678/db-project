from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user, require_admin
from app.security import hash_password


router = APIRouter(
    prefix="/api/staff",
    tags=["Staff"]
)


VALID_STATUSES = ["Active", "Inactive"]


class StaffCreate(BaseModel):
    staff_code: str = Field(
        min_length=1,
        max_length=20
    )
    name: str = Field(
        min_length=1,
        max_length=100
    )
    password: str = Field(
        min_length=6,
        max_length=255
    )
    phone: Optional[str] = Field(
        default=None,
        max_length=20
    )
    email: Optional[str] = Field(
        default=None,
        max_length=100
    )
    warehouse_id: Optional[int] = None
    status: str = "Active"


class StaffUpdate(BaseModel):
    staff_code: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=20
    )
    name: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=100
    )
    password: Optional[str] = Field(
        default=None,
        min_length=6,
        max_length=255
    )
    phone: Optional[str] = Field(
        default=None,
        max_length=20
    )
    email: Optional[str] = Field(
        default=None,
        max_length=100
    )
    warehouse_id: Optional[int] = None
    status: Optional[str] = None


@router.get("/")
def get_staff(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    result = db.execute(
        text("""
            SELECT
                staff_id,
                staff_code,
                name,
                phone,
                email,
                warehouse_id,
                status,
                created_at
            FROM staff
            ORDER BY staff_id ASC
        """)
    )

    staff = [
        dict(row)
        for row in result.mappings().all()
    ]

    return {
        "count": len(staff),
        "staff": staff
    }


@router.get("/{staff_id}")
def get_staff_member(
    staff_id: int,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    result = db.execute(
        text("""
            SELECT
                staff_id,
                staff_code,
                name,
                phone,
                email,
                warehouse_id,
                status,
                created_at
            FROM staff
            WHERE staff_id = :staff_id
        """),
        {"staff_id": staff_id}
    )

    staff = result.mappings().first()

    if not staff:
        raise HTTPException(
            status_code=404,
            detail="Staff member not found"
        )

    return {
        "staff": dict(staff)
    }


@router.post("/")
def create_staff(
    staff: StaffCreate,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    if staff.status not in VALID_STATUSES:
        raise HTTPException(
            status_code=400,
            detail="Status must be Active or Inactive"
        )

    existing = db.execute(
        text("""
            SELECT staff_id
            FROM staff
            WHERE staff_code = :staff_code
        """),
        {"staff_code": staff.staff_code}
    ).mappings().first()

    if existing:
        raise HTTPException(
            status_code=409,
            detail="Staff code already exists"
        )

    if staff.warehouse_id is not None:
        warehouse = db.execute(
            text("""
                SELECT warehouse_id
                FROM warehouses
                WHERE warehouse_id = :warehouse_id
            """),
            {"warehouse_id": staff.warehouse_id}
        ).mappings().first()

        if not warehouse:
            raise HTTPException(
                status_code=404,
                detail="Warehouse not found"
            )

    try:
        hashed_password = hash_password(staff.password)

        result = db.execute(
            text("""
                INSERT INTO staff (
                    staff_code,
                    name,
                    password,
                    phone,
                    email,
                    warehouse_id,
                    status
                )
                VALUES (
                    :staff_code,
                    :name,
                    :password,
                    :phone,
                    :email,
                    :warehouse_id,
                    :status
                )
            """),
            {
                "staff_code": staff.staff_code,
                "name": staff.name,
                "password": hashed_password,
                "phone": staff.phone,
                "email": staff.email,
                "warehouse_id": staff.warehouse_id,
                "status": staff.status
            }
        )

        db.commit()

        return {
            "message": "Staff member created successfully",
            "staff_id": result.lastrowid
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to create staff member"
        )


@router.put("/{staff_id}")
def update_staff(
    staff_id: int,
    staff: StaffUpdate,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    existing = db.execute(
        text("""
            SELECT staff_id
            FROM staff
            WHERE staff_id = :staff_id
        """),
        {"staff_id": staff_id}
    ).mappings().first()

    if not existing:
        raise HTTPException(
            status_code=404,
            detail="Staff member not found"
        )

    data = staff.model_dump(exclude_unset=True)

    if not data:
        raise HTTPException(
            status_code=400,
            detail="No fields provided for update"
        )

    if "status" in data:
        if data["status"] not in VALID_STATUSES:
            raise HTTPException(
                status_code=400,
                detail="Status must be Active or Inactive"
            )

    if "staff_code" in data:
        duplicate = db.execute(
            text("""
                SELECT staff_id
                FROM staff
                WHERE staff_code = :staff_code
                  AND staff_id <> :staff_id
            """),
            {
                "staff_code": data["staff_code"],
                "staff_id": staff_id
            }
        ).mappings().first()

        if duplicate:
            raise HTTPException(
                status_code=409,
                detail="Staff code already exists"
            )

    if "warehouse_id" in data and data["warehouse_id"] is not None:
        warehouse = db.execute(
            text("""
                SELECT warehouse_id
                FROM warehouses
                WHERE warehouse_id = :warehouse_id
            """),
            {"warehouse_id": data["warehouse_id"]}
        ).mappings().first()

        if not warehouse:
            raise HTTPException(
                status_code=404,
                detail="Warehouse not found"
            )

    if "password" in data:
        data["password"] = hash_password(
            data["password"]
        )

    allowed_fields = {
        "staff_code",
        "name",
        "password",
        "phone",
        "email",
        "warehouse_id",
        "status"
    }

    fields = [
        field
        for field in data.keys()
        if field in allowed_fields
    ]

    set_clause = ", ".join(
        f"{field} = :{field}"
        for field in fields
    )

    data["staff_id"] = staff_id

    try:
        db.execute(
            text(f"""
                UPDATE staff
                SET {set_clause}
                WHERE staff_id = :staff_id
            """),
            data
        )

        db.commit()

        return {
            "message": "Staff member updated successfully",
            "staff_id": staff_id
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to update staff member"
        )


@router.delete("/{staff_id}")
def delete_staff(
    staff_id: int,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    existing = db.execute(
        text("""
            SELECT staff_id
            FROM staff
            WHERE staff_id = :staff_id
        """),
        {"staff_id": staff_id}
    ).mappings().first()

    if not existing:
        raise HTTPException(
            status_code=404,
            detail="Staff member not found"
        )

    try:
        db.execute(
            text("""
                DELETE FROM staff
                WHERE staff_id = :staff_id
            """),
            {"staff_id": staff_id}
        )

        db.commit()

        return {
            "message": "Staff member deleted successfully",
            "staff_id": staff_id
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to delete staff member"
        )