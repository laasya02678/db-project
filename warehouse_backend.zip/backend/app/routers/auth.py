from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.database import get_db
from app.security import (
    verify_password,
    hash_password,
    create_access_token
)

router = APIRouter(
    prefix="/api/auth",
    tags=["Authentication"]
)


class AdminLoginRequest(BaseModel):
    username: str
    password: str


class StaffLoginRequest(BaseModel):
    staff_code: str
    password: str


def check_password_and_upgrade(
    entered_password: str,
    stored_password: str
) -> bool:
    """
    Supports the existing database passwords during migration.

    If the stored password is already an Argon2 hash,
    verify it securely.

    If it is still plain text, compare it once and the
    login route will replace it with an Argon2 hash.
    """

    if stored_password.startswith("$argon2"):
        try:
            return verify_password(
                entered_password,
                stored_password
            )
        except Exception:
            return False

    return entered_password == stored_password


@router.post("/admin-login")
def admin_login(
    login: AdminLoginRequest,
    db: Session = Depends(get_db)
):
    query = text("""
        SELECT
            admin_id,
            username,
            password,
            full_name,
            email
        FROM admins
        WHERE username = :username
        LIMIT 1
    """)

    result = db.execute(
        query,
        {"username": login.username}
    )

    admin = result.mappings().first()

    if not admin:
        raise HTTPException(
            status_code=401,
            detail="Invalid username or password"
        )

    stored_password = admin["password"]

    if not check_password_and_upgrade(
        login.password,
        stored_password
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid username or password"
        )

    # Upgrade an old plain-text password to Argon2
    if not stored_password.startswith("$argon2"):
        new_hash = hash_password(login.password)

        db.execute(
            text("""
                UPDATE admins
                SET password = :password
                WHERE admin_id = :admin_id
            """),
            {
                "password": new_hash,
                "admin_id": admin["admin_id"]
            }
        )

        db.commit()

    token = create_access_token(
        user_id=admin["admin_id"],
        role="admin"
    )

    return {
        "message": "Admin login successful",
        "access_token": token,
        "token_type": "bearer",
        "role": "admin",
        "user": {
            "id": admin["admin_id"],
            "username": admin["username"],
            "name": admin["full_name"],
            "email": admin["email"]
        }
    }


@router.post("/staff-login")
def staff_login(
    login: StaffLoginRequest,
    db: Session = Depends(get_db)
):
    query = text("""
        SELECT
            staff_id,
            staff_code,
            name,
            password,
            phone,
            email,
            warehouse_id,
            status
        FROM staff
        WHERE staff_code = :staff_code
        LIMIT 1
    """)

    result = db.execute(
        query,
        {"staff_code": login.staff_code}
    )

    staff = result.mappings().first()

    if not staff:
        raise HTTPException(
            status_code=401,
            detail="Invalid staff ID or password"
        )

    if staff["status"] != "Active":
        raise HTTPException(
            status_code=403,
            detail="Staff account is inactive"
        )

    stored_password = staff["password"]

    if not check_password_and_upgrade(
        login.password,
        stored_password
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid staff ID or password"
        )

    # Upgrade an old plain-text password to Argon2
    if not stored_password.startswith("$argon2"):
        new_hash = hash_password(login.password)

        db.execute(
            text("""
                UPDATE staff
                SET password = :password
                WHERE staff_id = :staff_id
            """),
            {
                "password": new_hash,
                "staff_id": staff["staff_id"]
            }
        )

        db.commit()

    token = create_access_token(
        user_id=staff["staff_id"],
        role="staff"
    )

    return {
        "message": "Staff login successful",
        "access_token": token,
        "token_type": "bearer",
        "role": "staff",
        "user": {
            "id": staff["staff_id"],
            "staff_code": staff["staff_code"],
            "name": staff["name"],
            "email": staff["email"],
            "warehouse_id": staff["warehouse_id"]
        }
    }