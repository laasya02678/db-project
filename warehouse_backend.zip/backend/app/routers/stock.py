from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user


router = APIRouter(
    prefix="/api/stock",
    tags=["Stock Transactions"]
)


class StockTransactionCreate(BaseModel):
    product_id: int
    warehouse_id: int
    staff_id: int
    transaction_type: str
    quantity: int = Field(gt=0)
    transaction_date: Optional[datetime] = None
    remarks: Optional[str] = Field(
        default=None,
        max_length=255
    )
    from_warehouse_id: Optional[int] = None


@router.get("/")
def get_stock_transactions(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = text("""
        SELECT
            st.transaction_id,
            st.product_id,
            p.product_code,
            p.product_name,
            st.warehouse_id,
            w.warehouse_code,
            st.staff_id,
            s.staff_code,
            s.name AS staff_name,
            st.transaction_type,
            st.quantity,
            st.transaction_date,
            st.remarks,
            st.from_warehouse_id
        FROM stock_transactions st
        LEFT JOIN products p
            ON st.product_id = p.product_id
        LEFT JOIN warehouses w
            ON st.warehouse_id = w.warehouse_id
        LEFT JOIN staff s
            ON st.staff_id = s.staff_id
        ORDER BY st.transaction_id DESC
    """)

    result = db.execute(query)

    transactions = [
        dict(row)
        for row in result.mappings().all()
    ]

    return {
        "count": len(transactions),
        "transactions": transactions
    }


@router.get("/{transaction_id}")
def get_stock_transaction(
    transaction_id: int,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = text("""
        SELECT
            st.transaction_id,
            st.product_id,
            p.product_code,
            p.product_name,
            st.warehouse_id,
            w.warehouse_code,
            st.staff_id,
            s.staff_code,
            s.name AS staff_name,
            st.transaction_type,
            st.quantity,
            st.transaction_date,
            st.remarks,
            st.from_warehouse_id
        FROM stock_transactions st
        LEFT JOIN products p
            ON st.product_id = p.product_id
        LEFT JOIN warehouses w
            ON st.warehouse_id = w.warehouse_id
        LEFT JOIN staff s
            ON st.staff_id = s.staff_id
        WHERE st.transaction_id = :transaction_id
    """)

    result = db.execute(
        query,
        {"transaction_id": transaction_id}
    )

    transaction = result.mappings().first()

    if not transaction:
        raise HTTPException(
            status_code=404,
            detail="Stock transaction not found"
        )

    return {
        "transaction": dict(transaction)
    }


@router.post("/")
def create_stock_transaction(
    transaction: StockTransactionCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    valid_types = [
        "Stock In",
        "Stock Out",
        "Stock Transfer"
    ]

    if transaction.transaction_type not in valid_types:
        raise HTTPException(
            status_code=400,
            detail="Invalid transaction type"
        )

    if (
        transaction.transaction_type == "Stock Transfer"
        and transaction.from_warehouse_id is None
    ):
        raise HTTPException(
            status_code=400,
            detail="from_warehouse_id is required for Stock Transfer"
        )

    # Check product
    product = db.execute(
        text("""
            SELECT
                product_id,
                quantity,
                warehouse_id
            FROM products
            WHERE product_id = :product_id
        """),
        {"product_id": transaction.product_id}
    ).mappings().first()

    if not product:
        raise HTTPException(
            status_code=404,
            detail="Product not found"
        )

    # Check destination warehouse
    warehouse = db.execute(
        text("""
            SELECT warehouse_id
            FROM warehouses
            WHERE warehouse_id = :warehouse_id
        """),
        {"warehouse_id": transaction.warehouse_id}
    ).mappings().first()

    if not warehouse:
        raise HTTPException(
            status_code=404,
            detail="Warehouse not found"
        )

    # Check staff
    staff = db.execute(
        text("""
            SELECT staff_id
            FROM staff
            WHERE staff_id = :staff_id
              AND status = 'Active'
        """),
        {"staff_id": transaction.staff_id}
    ).mappings().first()

    if not staff:
        raise HTTPException(
            status_code=404,
            detail="Active staff member not found"
        )

    # Check source warehouse for transfer
    if transaction.from_warehouse_id is not None:

        source_warehouse = db.execute(
            text("""
                SELECT warehouse_id
                FROM warehouses
                WHERE warehouse_id = :warehouse_id
            """),
            {
                "warehouse_id":
                    transaction.from_warehouse_id
            }
        ).mappings().first()

        if not source_warehouse:
            raise HTTPException(
                status_code=404,
                detail="Source warehouse not found"
            )

    try:
        current_quantity = product["quantity"]

        if transaction.transaction_type == "Stock In":

            db.execute(
                text("""
                    UPDATE products
                    SET quantity = quantity + :quantity
                    WHERE product_id = :product_id
                """),
                {
                    "quantity": transaction.quantity,
                    "product_id": transaction.product_id
                }
            )

        elif transaction.transaction_type == "Stock Out":

            if current_quantity < transaction.quantity:
                raise HTTPException(
                    status_code=400,
                    detail="Insufficient stock"
                )

            db.execute(
                text("""
                    UPDATE products
                    SET quantity = quantity - :quantity
                    WHERE product_id = :product_id
                """),
                {
                    "quantity": transaction.quantity,
                    "product_id": transaction.product_id
                }
            )

        elif transaction.transaction_type == "Stock Transfer":

            if current_quantity < transaction.quantity:
                raise HTTPException(
                    status_code=400,
                    detail="Insufficient stock for transfer"
                )

            db.execute(
                text("""
                    UPDATE products
                    SET warehouse_id = :warehouse_id
                    WHERE product_id = :product_id
                """),
                {
                    "warehouse_id": transaction.warehouse_id,
                    "product_id": transaction.product_id
                }
            )

        transaction_date = (
            transaction.transaction_date
            or datetime.now()
        )

        result = db.execute(
            text("""
                INSERT INTO stock_transactions (
                    product_id,
                    warehouse_id,
                    staff_id,
                    transaction_type,
                    quantity,
                    transaction_date,
                    remarks,
                    from_warehouse_id
                )
                VALUES (
                    :product_id,
                    :warehouse_id,
                    :staff_id,
                    :transaction_type,
                    :quantity,
                    :transaction_date,
                    :remarks,
                    :from_warehouse_id
                )
            """),
            {
                "product_id": transaction.product_id,
                "warehouse_id": transaction.warehouse_id,
                "staff_id": transaction.staff_id,
                "transaction_type":
                    transaction.transaction_type,
                "quantity": transaction.quantity,
                "transaction_date": transaction_date,
                "remarks": transaction.remarks,
                "from_warehouse_id":
                    transaction.from_warehouse_id
            }
        )

        db.commit()

        return {
            "message": "Stock transaction created successfully",
            "transaction_id": result.lastrowid
        }

    except HTTPException:
        db.rollback()
        raise

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to create stock transaction"
        )