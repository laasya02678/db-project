from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user


router = APIRouter(
    prefix="/api/settings",
    tags=["Settings"]
)


# --------------------------------------------------
# REQUEST MODEL
# --------------------------------------------------

class SettingsUpdate(BaseModel):
    system_name: str
    low_stock_limit: int
    default_warehouse_id: int | None = None
    currency: str = "INR"
    date_format: str = "DD-MM-YYYY"

    low_stock_alerts: bool = True
    order_notifications: bool = True
    stock_transfer_notifications: bool = True

    allow_negative_stock: bool = False
    session_timeout: int = 30
    dark_mode: bool = False


# --------------------------------------------------
# GET SETTINGS
# --------------------------------------------------

@router.get("")
def get_settings(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    try:

        result = db.execute(
            text("""
                SELECT
                    setting_id,
                    system_name,
                    low_stock_limit,
                    updated_at,
                    default_warehouse_id,
                    currency,
                    date_format,
                    low_stock_alerts,
                    order_notifications,
                    stock_transfer_notifications,
                    allow_negative_stock,
                    session_timeout,
                    dark_mode
                FROM settings
                LIMIT 1
            """)
        ).mappings().first()

        if not result:
            raise HTTPException(
                status_code=404,
                detail="Settings not found."
            )

        return {
            "settings": dict(result)
        }

    except HTTPException:
        raise

    except Exception as error:
        print("Settings GET API Error:", error)

        raise HTTPException(
            status_code=500,
            detail="Unable to load settings."
        )


# --------------------------------------------------
# UPDATE SETTINGS
# --------------------------------------------------

@router.put("")
def update_settings(
    settings: SettingsUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    try:

        # Basic validation
        if settings.low_stock_limit < 0:
            raise HTTPException(
                status_code=400,
                detail="Low stock limit cannot be negative."
            )

        if settings.session_timeout < 5:
            raise HTTPException(
                status_code=400,
                detail="Session timeout must be at least 5 minutes."
            )

        if settings.session_timeout > 1440:
            raise HTTPException(
                status_code=400,
                detail="Session timeout cannot exceed 1440 minutes."
            )

        if not settings.system_name.strip():
            raise HTTPException(
                status_code=400,
                detail="System name cannot be empty."
            )

        # Check whether settings record exists
        existing = db.execute(
            text("""
                SELECT setting_id
                FROM settings
                LIMIT 1
            """)
        ).mappings().first()

        if not existing:
            raise HTTPException(
                status_code=404,
                detail="Settings record not found."
            )

        # Update settings
        db.execute(
            text("""
                UPDATE settings
                SET
                    system_name = :system_name,
                    low_stock_limit = :low_stock_limit,
                    default_warehouse_id = :default_warehouse_id,
                    currency = :currency,
                    date_format = :date_format,
                    low_stock_alerts = :low_stock_alerts,
                    order_notifications = :order_notifications,
                    stock_transfer_notifications = :stock_transfer_notifications,
                    allow_negative_stock = :allow_negative_stock,
                    session_timeout = :session_timeout,
                    dark_mode = :dark_mode,
                    updated_at = CURRENT_TIMESTAMP
                WHERE setting_id = :setting_id
            """),
            {
                "system_name": settings.system_name.strip(),
                "low_stock_limit": settings.low_stock_limit,
                "default_warehouse_id": settings.default_warehouse_id,
                "currency": settings.currency,
                "date_format": settings.date_format,
                "low_stock_alerts": settings.low_stock_alerts,
                "order_notifications": settings.order_notifications,
                "stock_transfer_notifications":
                    settings.stock_transfer_notifications,
                "allow_negative_stock":
                    settings.allow_negative_stock,
                "session_timeout": settings.session_timeout,
                "dark_mode": settings.dark_mode,
                "setting_id": existing["setting_id"]
            }
        )

        db.commit()

        # Return updated settings
        updated = db.execute(
            text("""
                SELECT *
                FROM settings
                WHERE setting_id = :setting_id
            """),
            {
                "setting_id": existing["setting_id"]
            }
        ).mappings().first()

        return {
            "message": "Settings updated successfully.",
            "settings": dict(updated)
        }

    except HTTPException:
        raise

    except Exception as error:
        db.rollback()

        print("Settings UPDATE API Error:", error)

        raise HTTPException(
            status_code=500,
            detail="Unable to update settings."
        )