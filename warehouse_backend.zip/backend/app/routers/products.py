from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user, require_admin


router = APIRouter(
    prefix="/api/products",
    tags=["Products"]
)


class ProductCreate(BaseModel):
    product_code: str = Field(min_length=1, max_length=20)
    product_name: str = Field(min_length=1, max_length=100)
    category: str = Field(min_length=1, max_length=100)
    warehouse_id: Optional[int] = None
    quantity: int = Field(default=0, ge=0)
    price: float = Field(gt=0)
    supplier_id: Optional[int] = None
    reorder_level: int = Field(default=10, ge=0)
    status: str = "Available"


class ProductUpdate(BaseModel):
    product_code: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=20
    )
    product_name: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=100
    )
    category: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=100
    )
    warehouse_id: Optional[int] = None
    quantity: Optional[int] = Field(
        default=None,
        ge=0
    )
    price: Optional[float] = Field(
        default=None,
        gt=0
    )
    supplier_id: Optional[int] = None
    reorder_level: Optional[int] = Field(
        default=None,
        ge=0
    )
    status: Optional[str] = None


@router.get("/")
def get_products(
    search: Optional[str] = Query(
        default=None,
        max_length=100
    ),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if search:
        query = text("""
            SELECT
                product_id,
                product_code,
                product_name,
                category,
                warehouse_id,
                quantity,
                price,
                supplier_id,
                reorder_level,
                status,
                created_at,
                updated_at
            FROM products
            WHERE product_code LIKE :search
               OR product_name LIKE :search
               OR category LIKE :search
            ORDER BY product_id DESC
        """)

        result = db.execute(
            query,
            {"search": f"%{search}%"}
        )
    else:
        query = text("""
            SELECT
                product_id,
                product_code,
                product_name,
                category,
                warehouse_id,
                quantity,
                price,
                supplier_id,
                reorder_level,
                status,
                created_at,
                updated_at
            FROM products
            ORDER BY product_id DESC
        """)

        result = db.execute(query)

    return {
        "count": result.rowcount if result.rowcount >= 0 else None,
        "products": [dict(row) for row in result.mappings().all()]
    }


@router.get("/{product_id}")
def get_product(
    product_id: int,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = text("""
        SELECT
            product_id,
            product_code,
            product_name,
            category,
            warehouse_id,
            quantity,
            price,
            supplier_id,
            reorder_level,
            status,
            created_at,
            updated_at
        FROM products
        WHERE product_id = :product_id
    """)

    result = db.execute(
        query,
        {"product_id": product_id}
    )

    product = result.mappings().first()

    if not product:
        raise HTTPException(
            status_code=404,
            detail="Product not found"
        )

    return {
        "product": dict(product)
    }


@router.post("/")
def create_product(
    product: ProductCreate,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    if product.status not in ["Available", "Inactive"]:
        raise HTTPException(
            status_code=400,
            detail="Status must be Available or Inactive"
        )

    existing = db.execute(
        text("""
            SELECT product_id
            FROM products
            WHERE product_code = :product_code
        """),
        {"product_code": product.product_code}
    ).mappings().first()

    if existing:
        raise HTTPException(
            status_code=409,
            detail="Product code already exists"
        )

    try:
        result = db.execute(
            text("""
                INSERT INTO products (
                    product_code,
                    product_name,
                    category,
                    warehouse_id,
                    quantity,
                    price,
                    supplier_id,
                    reorder_level,
                    status
                )
                VALUES (
                    :product_code,
                    :product_name,
                    :category,
                    :warehouse_id,
                    :quantity,
                    :price,
                    :supplier_id,
                    :reorder_level,
                    :status
                )
            """),
            product.model_dump()
        )

        db.commit()

        return {
            "message": "Product created successfully",
            "product_id": result.lastrowid
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to create product"
        )


@router.put("/{product_id}")
def update_product(
    product_id: int,
    product: ProductUpdate,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    existing = db.execute(
        text("""
            SELECT product_id
            FROM products
            WHERE product_id = :product_id
        """),
        {"product_id": product_id}
    ).mappings().first()

    if not existing:
        raise HTTPException(
            status_code=404,
            detail="Product not found"
        )

    data = product.model_dump(exclude_unset=True)

    if not data:
        raise HTTPException(
            status_code=400,
            detail="No fields provided for update"
        )

    if "status" in data and data["status"] not in [
        "Available",
        "Inactive"
    ]:
        raise HTTPException(
            status_code=400,
            detail="Status must be Available or Inactive"
        )

    if "product_code" in data:
        duplicate = db.execute(
            text("""
                SELECT product_id
                FROM products
                WHERE product_code = :product_code
                  AND product_id <> :product_id
            """),
            {
                "product_code": data["product_code"],
                "product_id": product_id
            }
        ).mappings().first()

        if duplicate:
            raise HTTPException(
                status_code=409,
                detail="Product code already exists"
            )

    allowed_fields = {
        "product_code",
        "product_name",
        "category",
        "warehouse_id",
        "quantity",
        "price",
        "supplier_id",
        "reorder_level",
        "status"
    }

    fields = [
        field
        for field in data.keys()
        if field in allowed_fields
    ]

    set_clause = ", ".join(
        f"{field} = :{field}"
        for field in fields
    )

    data["product_id"] = product_id

    try:
        db.execute(
            text(f"""
                UPDATE products
                SET {set_clause}
                WHERE product_id = :product_id
            """),
            data
        )

        db.commit()

        return {
            "message": "Product updated successfully",
            "product_id": product_id
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to update product"
        )


@router.delete("/{product_id}")
def delete_product(
    product_id: int,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    existing = db.execute(
        text("""
            SELECT product_id
            FROM products
            WHERE product_id = :product_id
        """),
        {"product_id": product_id}
    ).mappings().first()

    if not existing:
        raise HTTPException(
            status_code=404,
            detail="Product not found"
        )

    try:
        db.execute(
            text("""
                DELETE FROM products
                WHERE product_id = :product_id
            """),
            {"product_id": product_id}
        )

        db.commit()

        return {
            "message": "Product deleted successfully",
            "product_id": product_id
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to delete product"
        )