from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user, require_admin


router = APIRouter(
    prefix="/api/suppliers",
    tags=["Suppliers"]
)


VALID_STATUSES = ["Active", "Inactive"]


class SupplierCreate(BaseModel):
    supplier_code: str = Field(
        min_length=1,
        max_length=20
    )
    supplier_name: str = Field(
        min_length=1,
        max_length=100
    )
    contact: Optional[str] = Field(
        default=None,
        max_length=20
    )
    email: Optional[str] = Field(
        default=None,
        max_length=100
    )
    address: Optional[str] = Field(
        default=None,
        max_length=255
    )
    status: str = "Active"


class SupplierUpdate(BaseModel):
    supplier_code: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=20
    )
    supplier_name: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=100
    )
    contact: Optional[str] = Field(
        default=None,
        max_length=20
    )
    email: Optional[str] = Field(
        default=None,
        max_length=100
    )
    address: Optional[str] = Field(
        default=None,
        max_length=255
    )
    status: Optional[str] = None


@router.get("/")
def get_suppliers(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    result = db.execute(
        text("""
            SELECT
                supplier_id,
                supplier_code,
                supplier_name,
                contact,
                email,
                address,
                status,
                created_at
            FROM suppliers
            ORDER BY supplier_id ASC
        """)
    )

    suppliers = [
        dict(row)
        for row in result.mappings().all()
    ]

    return {
        "count": len(suppliers),
        "suppliers": suppliers
    }


@router.get("/{supplier_id}")
def get_supplier(
    supplier_id: int,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    result = db.execute(
        text("""
            SELECT
                supplier_id,
                supplier_code,
                supplier_name,
                contact,
                email,
                address,
                status,
                created_at
            FROM suppliers
            WHERE supplier_id = :supplier_id
        """),
        {"supplier_id": supplier_id}
    )

    supplier = result.mappings().first()

    if not supplier:
        raise HTTPException(
            status_code=404,
            detail="Supplier not found"
        )

    return {
        "supplier": dict(supplier)
    }


@router.post("/")
def create_supplier(
    supplier: SupplierCreate,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    if supplier.status not in VALID_STATUSES:
        raise HTTPException(
            status_code=400,
            detail="Status must be Active or Inactive"
        )

    existing = db.execute(
        text("""
            SELECT supplier_id
            FROM suppliers
            WHERE supplier_code = :supplier_code
        """),
        {"supplier_code": supplier.supplier_code}
    ).mappings().first()

    if existing:
        raise HTTPException(
            status_code=409,
            detail="Supplier code already exists"
        )

    try:
        result = db.execute(
            text("""
                INSERT INTO suppliers (
                    supplier_code,
                    supplier_name,
                    contact,
                    email,
                    address,
                    status
                )
                VALUES (
                    :supplier_code,
                    :supplier_name,
                    :contact,
                    :email,
                    :address,
                    :status
                )
            """),
            supplier.model_dump()
        )

        db.commit()

        return {
            "message": "Supplier created successfully",
            "supplier_id": result.lastrowid
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to create supplier"
        )


@router.put("/{supplier_id}")
def update_supplier(
    supplier_id: int,
    supplier: SupplierUpdate,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    existing = db.execute(
        text("""
            SELECT supplier_id
            FROM suppliers
            WHERE supplier_id = :supplier_id
        """),
        {"supplier_id": supplier_id}
    ).mappings().first()

    if not existing:
        raise HTTPException(
            status_code=404,
            detail="Supplier not found"
        )

    data = supplier.model_dump(exclude_unset=True)

    if not data:
        raise HTTPException(
            status_code=400,
            detail="No fields provided for update"
        )

    if "status" in data and data["status"] not in VALID_STATUSES:
        raise HTTPException(
            status_code=400,
            detail="Status must be Active or Inactive"
        )

    if "supplier_code" in data:
        duplicate = db.execute(
            text("""
                SELECT supplier_id
                FROM suppliers
                WHERE supplier_code = :supplier_code
                  AND supplier_id <> :supplier_id
            """),
            {
                "supplier_code": data["supplier_code"],
                "supplier_id": supplier_id
            }
        ).mappings().first()

        if duplicate:
            raise HTTPException(
                status_code=409,
                detail="Supplier code already exists"
            )

    allowed_fields = {
        "supplier_code",
        "supplier_name",
        "contact",
        "email",
        "address",
        "status"
    }

    fields = [
        field
        for field in data.keys()
        if field in allowed_fields
    ]

    set_clause = ", ".join(
        f"{field} = :{field}"
        for field in fields
    )

    data["supplier_id"] = supplier_id

    try:
        db.execute(
            text(f"""
                UPDATE suppliers
                SET {set_clause}
                WHERE supplier_id = :supplier_id
            """),
            data
        )

        db.commit()

        return {
            "message": "Supplier updated successfully",
            "supplier_id": supplier_id
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to update supplier"
        )


@router.delete("/{supplier_id}")
def delete_supplier(
    supplier_id: int,
    current_user: dict = Depends(require_admin),
    db: Session = Depends(get_db)
):
    existing = db.execute(
        text("""
            SELECT supplier_id
            FROM suppliers
            WHERE supplier_id = :supplier_id
        """),
        {"supplier_id": supplier_id}
    ).mappings().first()

    if not existing:
        raise HTTPException(
            status_code=404,
            detail="Supplier not found"
        )

    try:
        db.execute(
            text("""
                DELETE FROM suppliers
                WHERE supplier_id = :supplier_id
            """),
            {"supplier_id": supplier_id}
        )

        db.commit()

        return {
            "message": "Supplier deleted successfully",
            "supplier_id": supplier_id
        }

    except Exception:
        db.rollback()

        raise HTTPException(
            status_code=400,
            detail="Unable to delete supplier"
        )