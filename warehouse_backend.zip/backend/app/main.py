from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from app.database import engine
from app.routers import auth
from app.dependencies import require_admin, require_staff
from app.routers import products
from app.routers import stock
from app.routers import orders
from app.routers import staff
from app.routers import suppliers
from app.routers import warehouse
from app.routers import settings


app = FastAPI(
    title="Inventory & Warehouse Management API",
    version="1.0.0"
)
app.include_router(auth.router)
app.include_router(products.router)
app.include_router(stock.router)
app.include_router(orders.router)
app.include_router(staff.router)
app.include_router(suppliers.router)
app.include_router(warehouse.router)
app.include_router(settings.router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def home():
    return {
        "message": "Inventory & Warehouse Management API is running"
    }


@app.get("/api/health")
def health():
    return {
        "status": "success",
        "message": "Backend is working"
    }


@app.get("/api/database-test")
def database_test():

    with engine.connect() as connection:

        result = connection.execute(
            text("SELECT COUNT(*) FROM products")
        )

        count = result.scalar()

    return {
        "database": "connected",
        "products": count
    }
@app.get("/api/admin-test")
def admin_test(current_user: dict = Depends(require_admin)):
    return {
        "message": "Admin authorization successful",
        "user_id": current_user["user_id"],
        "role": current_user["role"]
    }


@app.get("/api/staff-test")
def staff_test(current_user: dict = Depends(require_staff)):
    return {
        "message": "Staff authorization successful",
        "user_id": current_user["user_id"],
        "role": current_user["role"]
    }