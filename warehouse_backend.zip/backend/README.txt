BACKEND
FastAPI backend for the Warehouse Management System.

Install dependencies from requirements.txt and run the FastAPI app using app.main:app.
